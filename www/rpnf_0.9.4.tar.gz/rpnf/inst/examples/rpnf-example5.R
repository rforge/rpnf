#' Create xts with short/long positions
GetTradeRule <- function(pnf,rs,bp,short=F,
                         type=c(
                           "BuyAndHold",
                           "BuyAndSellOnStatus",
                           "BuyAndSellOnStatusAndSignal",
                           "BuyAndSellOnRelativeStrengthStatus",
                           
                         )) {
  if (type=="BuyAndHold")
    TRSBuyAndHold(pnf)
  else if (type=="BuyAndSellOnStatus")
    TRSBuyAndSellOnStatus(pnf,short)
  else if (type=="BuyAndSellOnStatusAndSignal")
    TRSBuyAndSellOnStatusAndSignal(pnf,short)
  else if (type=="BuyAndSellOnRelativeStrengthStatus")
    TRSBuyAndSellOnRelativeStrengthStatus(pnf,short)
  else if (type=="BuyAndSellOnSpecialSignal")
    TRSBuyAndSellOnSpecialSignal(pnf,short)
  else
    stop("Unknown trade rule type!")
}

#' Trade rule strategy: buy and hold
TRSBuyAndHold <- function(data) {
  tr.change <- rep(0,times=nrow(data))
  tr.saldo <- rep(0,times=nrow(data)) 
  # buy at first day
  tr.change[3] = 1;
  tr.saldo <- tr.saldo+cumsum(tr.change)
  # return
  xts(cbind(tr.change,tr.saldo),order.by=data$date)
}

#' Trade rule strategy: BuyAndSellOnStatus
TRSBuyAndSellOnStatus <- function(data,short=F) {
  tr.change <- rep(0,times=nrow(data))
  tr.saldo <- rep(0,times=nrow(data))
  # do trade the day after the signal change
  for (i in 3:nrow(data)) {
    if (data$status.bs[i-2]!=data$status.bs[i-1] & data$status.bs[i-1]==data$status.bs[i]) {
      # status changed => act
      if (data$status.bs[i]=="Buy") {
        tr.change[i] <- -tr.saldo[i] + 1
      } else if (data$status.bs[i]=="Sell") {
        tr.change[i] <- -tr.saldo[i] - short
      }
      tr.saldo[i:nrow(data)] <- tr.saldo[i:nrow(data)]+tr.change[i]
    }
  }
  xts(cbind(tr.change,tr.saldo),order.by=data$date)
}

#' Trade rule strategy: BuyAndSellOnStatusAndSignal
TRSBuyAndSellOnStatusAndSignal <- function(data,short=F) {
  tr.change <- rep(0,times=nrow(data))
  tr.saldo <- rep(0,times=nrow(data))
  # do trade the day after the signal change
  for (i in 3:nrow(data)) {
    if (data$status.bs[i-2]!=data$status.bs[i-1] & data$status.bs[i-1]==data$status.bs[i]) {
      # status changed => act
      if (data$status.bs[i]=="Buy" & data$tl.status[i]=="BULLISH") {
        tr.change[i] <- -tr.saldo[i] + 1
        #      } else if (data$status.bs[i]=="Sell") {
      } else if (data$status.bs[i]=="Sell" & data$tl.status[i]!="BULLISH") {
        tr.change[i] <- -tr.saldo[i] - short
      }
      tr.saldo[i:nrow(data)] <- tr.saldo[i:nrow(data)]+tr.change[i]
    }
  }
  xts(cbind(tr.change,tr.saldo),order.by=data$date)
}

#' Trade rule strategy: 
TRSBuyAndSellOnSpecialSignal <- function(data,short=F) {
  tr.change <- rep(0,times=nrow(data))
  tr.saldo <- rep(0,times=nrow(data))
  # do trade the day after the signal change
  for (i in 3:nrow(data)) {
    if (data$signal.bs[i-2]!=data$signal.bs[i-1] & data$signal.bs[i-1]=="BULLISH SIGNAL") {
      # status changed => act
      tr.change[i] <- -tr.saldo[i] + 1
    } else if (data$status.bs[i-1]=="Sell" & data$tl.status[i-1]!="BULLISH") {
      tr.change[i] <- -tr.saldo[i] - short
    }
    tr.saldo[i:nrow(data)] <- tr.saldo[i:nrow(data)]+tr.change[i]
    
  }
  xts(cbind(tr.change,tr.saldo),order.by=data$date)
}

#' Trade rule strategy: ..
TRSBuyAndSellOnRelativeStrengthStatus <- function(rs,short=F) {
  tr.change <- rep(0,times=nrow(rs))
  tr.saldo <- rep(0,times=nrow(rs))
  # do trade the day after the signal change
  for (i in 3:nrow(rs)) {
    if (rs$status.bs[i-2]!=rs$status.bs[i-1] & rs$status.bs[i-1]==rs$status.bs[i]) {
      # status changed => act
      if (rs$status.bs[i]=="Buy") {
        tr.change[i] <- -tr.saldo[i] + 1
      } else {
        tr.change[i] <- -tr.saldo[i] - short
      }
      tr.saldo[i:nrow(data)] <- tr.saldo[i:nrow(data)]+tr.change[i]
    }
  }
  xts(cbind(tr.change,tr.saldo),order.by=data$date)
}

#' Evaluation of a given change/saldo position
foo2 <-function(quotes,traderules,initial=1000,spesen=12,fix.position.size=F) {
  # initiallize 
  traderules$konto.saldo<-initial
  traderules$depot.saldo<-0
  traderules$depot.change<-0
  traderules$konto.spesen<-abs(spesen*traderules$tr.change)
  #
  n <- nrow(traderules) 
  for (i in 2:n) {
    # 
    if (traderules$tr.change[i]!=0) {
      # determine number of stocks to buy or sell
      if (traderules$tr.change[i]>0)
        if (fix.position.size) {
          traderules$depot.change[i] = floor((initial)/quotes$open[index(traderules[i])])
        } else {
          traderules$depot.change[i] = floor((traderules$konto.saldo[i])/quotes$open[index(traderules[i])])
        }
      else 
        traderules$depot.change[i] = -(traderules$depot.saldo[i-1])
      # update traderules$depot.saldo
      traderules$depot.saldo <- cumsum(traderules$depot.change)
      # update konto.saldo
      traderules$konto.saldo<- initial - traderules$konto.spesen + cumsum(-traderules$depot.change*quotes$open)
      # printprogress
      #printProgress(i,n)
    }
  }
  
  #   # perform fixed point iteration
  #   n <- sum(abs(traderules$tr.change))+1 
  #   #start.time <- Sys.time()
  #   for (i in 1:n) {
  #     # determine number of stocks to be bought
  #     traderules$depot.change = floor((traderules$konto.saldo)/quotes$open)*(traderules$tr.change>0) -
  #       (traderules$depot.saldo)*(traderules$tr.change<0)
  #     # update depot.saldo
  #     traderules$depot.saldo <- cumsum(traderules$depot.change)
  #     # determine number of stocks to be bought
  #     traderules$depot.change = floor((traderules$konto.saldo)/quotes$open)*(traderules$tr.change>0) -
  #       (traderules$depot.saldo)*(traderules$tr.change<0)
  #     # update konto.saldo
  #     traderules$konto.saldo<- initial - traderules$konto.spesen + cumsum(-traderules$depot.change*quotes$open)
  #     # printprogress
  #     printProgress(i,n)
  #   }
  # determine overall development
  traderules$overall <- traderules$konto.saldo + traderules$depot.saldo*quotes$close 
  traderules
}

#'Evaluate all stocks 
foo3 <- function(pnfdata,rsdata,bpdata,tradeRuleType="BuyAndHold") {
  overall <-0
  for (symbol in symbolTable[,2]) {
    print(paste("processing symbol: ",symbol))
    symbol.xts <- GetSymbolXTS(symbol)
    symbol.pnf <- GetSymbolPNF(symbol,pnfdata)
    symbol.rs <- GetSymbolPNF(symbol,rsdata)
    traderules <- GetTradeRule(symbol.pnf,symbol.rs,bpdata,type=tradeRuleType)
    results<- NULL
    results <- foo2(symbol.xts,traderules)
    #    try(results <- foo2(symbol.xts,traderules))
    if (!is.null(results)) {
      plot(results$overall,main=paste("Overall performance for ",symbol))
      abline(h=1000,col="red")
      print(results$overall[nrow(results$overall)])
      
      overall <- overall + as.numeric(results$overall[nrow(results$overall)])
    } else {
      overall <- overall + 1000 # initial
    }
  }
  print(overall)
}

#'
GetSymbolXTS <- function(symbol) {
  symbol.xts <- eval(parse(text=paste("OHLC(stockData$",sub("^\\^","",symbol),")",sep="")))
}

#'
GetSymbolPNF <- function(symbol,pnfdata) {
  symbol.pnf <- pnfdata[pnfdata$symbol==symbol,]
}

